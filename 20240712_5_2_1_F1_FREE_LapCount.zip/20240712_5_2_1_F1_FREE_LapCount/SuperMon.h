/*


  OK, ya ready for some fun? HTML + CSS styling + javascript all in and undebuggable environment

  one trick I've learned to how to debug HTML and CSS code.

  get all your HTML code (from html to /html) and past it into this test site
  muck with the HTML and CSS code until it's what you want
  https://www.w3schools.com/html/tryit.asp?filename=tryhtml_intro

  No clue how to debug javascrip other that write, compile, upload, refresh, guess, repeat

  I'm using class designators to set styles and id's for data updating
  for example:
  the CSS class .tabledata defines with the cell will look like
  <td><div class="tabledata" id = "switch"></div></td>

  the XML code will update the data where id = "switch"
  java script then uses getElementById
  document.getElementById("switch").innerHTML="Switch is OFF";


  .. now you can have the class define the look AND the class update the content, but you will then need
  a class for every data field that must be updated, here's what that will look like
  <td><div class="switch"></div></td>

  the XML code will update the data where class = "switch"
  java script then uses getElementsByClassName
  document.getElementsByClassName("switch")[0].style.color=text_color;


  the main general sections of a web page are the following and used here

  <html>
    <style>
    // dump CSS style stuff in here
    </style>
    <body>
      <header>
      // put header code for cute banners here
      </header>
      <main>
      // the buld of your web page contents
      </main>
      <footer>
      // put cute footer (c) 2021 xyz inc type thing
      </footer>
    </body>
    <script>
    // you java code between these tags
    </script>
  </html>


*/

// note R"KEYWORD( html page code )KEYWORD";
// again I hate strings, so char is it and this method let's us write naturally

const char PAGE_MAIN[] PROGMEM = R"=====(

<!DOCTYPE html>
<html lang="en" class="js-focus-visible">

 <!-- tag before the code and tag after the code that you want to hide --> 

<title>Wolles lap counter</title>

  <style>
    table {
      position: relative;
      width:100%;
      border-spacing: 0px;
    }
    tr {
      border: 1px solid black;
      font-family: "Verdana", "Arial", sans-serif;
      font-size: 20px;
    }
    th {
      height: 25px;
      padding: 3px 5px;
      background-color: black;
      color: #FFFFFF !important;
      font-weight: bold;
      font-style: oblique 15deg;
      }
    td {
      height: 20px;
      padding: 3px 5px;
      background-color: black;
    }
    .tabledata {
      font-size: 28px;
      position: relative;
      padding-left: 7px;
      padding-top: 7px;
      height:   36px;
      color: red;
      line-height: 30px;
      transition: all 200ms ease-in-out;
      background-color: black;
      font-weight: bold;
    }
 .tabledatay {
      font-size: 26px;
      position: relative;
      padding-left: 7px;
      padding-top: 7px;
      height:   36px;
      color: yellow;
      line-height: 30px;
      transition: all 200ms ease-in-out;
      background-color: black;
      font-weight: bold;
    }

.tabledatatop {
      font-size: 70px;
      position: relative;
      padding-left: 7px;
      padding-top: 7px;
      height:   36px;
      color: red;
      line-height: 30px;
      transition: all 200ms ease-in-out;
      background-color: black;
      font-weight: bold;
    }

.tabledataWin {
      font-size: 40px;
      position: relative;
      padding-left: 7px;
      padding-top: 7px;
      height:   36px;
      color: red;
      line-height: 30px;
      transition: all 200ms ease-in-out;
      background-color: black;
      font-weight: bold;
    }

    .fanrpmslider {
      width: 30%;
      height: 55px;
      outline: none;
      height: 25px;
    }
    .bodytext {
      font-family: "Verdana", "Arial", sans-serif;
      font-size: 24px;
      text-align: left;
      font-weight: light;
      border-radius: 5px;
      display:inline;
      color: white;
      background-color: black;
       font-style: oblique 15deg;
    }
    .navbar {
      width: 100%;
      height: 50px;
      margin: 0;
      padding: 10px 0px;
      background-color: black;
      color: #000000;
      border-bottom: 5px solid #293578;
    }
    .fixed-top {
      position: fixed;
      top: 0;
      right: 0;
      left: 0;
      z-index: 1030;
    }
    .navtitle {
      float: left;
      height: 50px;
      font-family: "Verdana", "Arial", sans-serif;
      font-size: 44px;
      font-weight: bold;
      line-height: 50px;
      padding-left: 20px;
      font-style: oblique 15deg;
      background-color: black;
      color: white;
    }

   .navwwroooom {
     position: fixed;
     left: 45%;
     height: 20px;
     font-family: "Verdana", "Arial", sans-serif;
     font-size: 28px;
     font-weight: bold;
     line-height: 50px;
     padding-right: 20px;
     font-style: oblique 15deg;     
     color: #22FB03;
   }
   .navheading {
     position: fixed;
     left: 75%;
     height: 50px;
     font-family: "Verdana", "Arial", sans-serif;
     font-size: 20px;
     font-weight: bold;
     line-height: 40px;
     padding-right: 20px;
     font-style: oblique 15deg;     
     color: white;
   }
   .navdata {
      justify-content: flex-end;
      position: fixed;
      left: 85%;
      height: 50px;
      font-family: "Verdana", "Arial", sans-serif;
      font-size: 20px;
      font-weight: bold;
      line-height: 40px;
      padding-right: 20px;
      font-style: oblique 15deg;
      color: white;
   }
    .category {
      font-family: "Verdana", "Arial", sans-serif;
      font-weight: bold;
      font-size: 32px;
      line-height: 50px;
      padding: 20px 10px 0px 10px;
      color: #000000;
    }
    .heading {
      font-family: "Verdana", "Arial", sans-serif;
      font-weight: normal;
      font-size: 34px;
      text-align: left;
      font-weight: bold;
    }
    .btn {
      background-color: blue;
      border: none;
      color: white;
      padding: 10px 20px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 28px;
      margin: 4px 2px;
      cursor: pointer;
      font-weight: bold;
      border-radius: 12px;
    }

    .btn_blue {
      background-color: blue;
      border: none;
      color: white;
      padding: 10px 20px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 28px;
      margin: 4px 2px;
      cursor: pointer;
      font-weight: bold;
      border-radius: 12px;
    }

    .btn_green {
      background-color: green;
      border: none;
      color: white;
      padding: 10px 20px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 28px;
      margin: 4px 2px;
      cursor: pointer;
      font-weight: bold;
      border-radius: 12px;
    }

    .btn_red {
      background-color: red;
      border: none;
      color: white;
      padding: 10px 20px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 28px;
      margin: 4px 2px;
      cursor: pointer;
      font-weight: bold;
      border-radius: 12px;
    }

    .foot {
      font-family: "Verdana", "Arial", sans-serif;
      font-size: 20px;
      position: relative;
      height:   30px;
      text-align: center;   
      color: #AAAAAA;
      line-height: 20px;
    }
    .container {
      max-width: 1800px;
      margin: 0 auto;
    }
   
  </style>

  <body style="background-color: black" #efefef  onload="process()">
  
    <header>
      <div class="navbar fixed-top">
          <div class="container">
            <div class="navtitle">Wolle's laps</div>
            <div class="navwwroooom">wroaaoooom</div>
            <div class="navdata" id = "date">mm/dd/yyyy</div>
            <div class="navheading"></div><br>
            <div class="navdata" id = "time">00:00:00</div>
            <div class="navheading"> </div>
            
          </div>
      </div>
    </header>
  
    <main class="container" style="margin-top:50px">

      </div>
      <div class="category">Sensor Controls</div>
  
      <div class="bodytext"> </div>
      <button type="button" class = "btn" id = "btn10" onclick="ButtonPress10()">10 laps</button>
      </div>
    
      <div class="bodytext">..</div>
      <button type="button" class = "btn" id = "btn50" onclick="ButtonPress50()">50 laps</button>
      </div>

      <div class="bodytext">..</div>
      <button type="button" class = "btn" id = "btn100" onclick="ButtonPress100()">100 laps</button>
      </div>

      <div class="bodytext">..</div>
      <button type="button" class = "btn" id = "btn200" onclick="ButtonPress200()">200 laps</button>
      </div>

      <!-- <div class="category">Sensor Readings</div> -->
      <br>
      <div class="bodytext">  <br> </div>

 <table style="width:100%">
      <colgroup>
        <col span="1" style="background-color:rgb(180,180,180); width: 22%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 27%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 27%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 24%; color:#000000 ;">
      </colgroup>

      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">

      <tr>
        <td><div class="tabledata">  </div></td>
        <td><div class="tabledatatop" id ="s1" ></div></td>
        <td><div class="tabledatatop" id ="s2" ></div></td>
        <td><div class="tabledatatop" id = >   </div></td>
      </tr>

      <tr>
        <td><div class="tabledata">  </div></td>
        <td><div class="tabledataWin" id ="w1" ></div></td>
        <td><div class="tabledataWin" id ="w2" ></div> </td>
        <td><div class="tabledataWin" id = ></div></td>
      </tr>
      </table>


      <table style="width:100%">
      <colgroup>
        <col span="1" style="background-color:rgb(180,180,180); width: 22%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 27%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 27%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 24%; color:#000000 ;">
      </colgroup>
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <tr>
        <th colspan="1"><div class="heading">race</div></th>
        <th colspan="1"><div class="heading">slot 1</div></th>
        <th colspan="1"><div class="heading">slot 2</div></th>
        <th colspan="1"><div class="heading">diff</div></th>
      </tr>

      <tr>
        <td><div class="tabledatay"> laps to go:</div></td>
        <td><div class="tabledatay"  id = "l1"></div></td>
        <td><div class="tabledatay"  id = "l2"></div></td>
        <td><div class="tabledatay"  id = "l3"></div></td>
      </tr>

      <tr>
        <td><div class="tabledata">last lap:</div></td>
        <td><div class="tabledata" id = "t1" ></div></td>
        <td><div class="tabledata" id = "t2" ></div></td>
        <td><div class="tabledata" id = "t3" ></div></td>
      </tr>

      <tr>
        <td><div class="tabledata">best lap:</div></td>
        <td><div class="tabledata" id = "e1"></div></td>
        <td><div class="tabledata" id = "e2"></div></td>
        <td><div class="tabledata" id = "e3"></div></td>

      </tr>

      <tr>
        <td><div class="tabledata">av lap:</div></td>
        <td><div class="tabledata" id = "a1"></div></td>
        <td><div class="tabledata" id = "a2"></div></td>
        <td><div class="tabledata" id = "a3"></div></td>
      </tr>


      <tr>
        <td><div class="tabledata">tot time:</div></td>
        <td><div class="tabledata" id = "o1"></div></td>
        <td><div class="tabledata" id = "o2"></div></td>
        <td><div class="tabledata" id = "o3"></div></td>
      </tr>


      <tr>
        <td><div class="tabledata">penalty:</div></td>
        <td><div class="tabledata" id = "n1"></div></td>
        <td><div class="tabledata" id = "n2"></div></td>
        <td><div class="tabledata" id = ></div></td>
      </tr>




      <tr>
        <td><div class="tabledata">speed:</div></td>
        <td><div class="tabledata" id = "p1"></div></td>
        <td><div class="tabledata" id = "p2"></div></td>
        <td><div class="tabledata" id = "p3"></div></td>
      </tr>

      </table>

      </div>
      <!-- <div class="category">Sensor Readings</div> -->

      <br>

      <div class="bodytext">  </div>
      <button type="button" class = "btn_green" id = "btn01" onclick="ButtonPress01()"> - start ! - </button>
      </div>

      <div class="bodytext">..</div>
      <button type="button" class = "btn_red" id = "btn00" onclick="ButtonPress00()"> - stop ! - </button>
      </div>

      <div class="bodytext">......</div>
      <button type="button" class = "btn_blue" id = "btnr1" onclick="ButtonPressr1()"> - reset ! - </button>
      </div>

   <br>
      <div class="bodytext">  <br> </div>

 <table style="width:100%">
      <colgroup>
        <col span="1" style="background-color:rgb(180,180,180); width: 20%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 20%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 20%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 20%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 20%; color:#000000 ;">
      </colgroup>

      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">

      <tr>
        <td><div class="tabledata"> race laps:    </div></td>
        <td><div class="tabledata"> track/m: </div></td>
        <td><div class="tabledata"> scale: </div></td>
        <td><div class="tabledata"> Wifi:    </div></td>
        <td><div class="tabledata"> version:    </div></td>
      </tr>

      <tr>
        <td><div class="tabledata" id = "l0"></div></td>
        <td><div class="tabledata" id = "sl"></div></td>
        <td><div class="tabledata" id = "sf"></div></td>
        <td><div class="tabledata" id = "wi"></div></td>
        <td><div class="tabledata" id = "ve"></div></td>
      </tr>
      </table>

      <br>
      <div class="bodytext">experimental  <br> </div>

      <table style="width:100%">
      <colgroup>
        <col span="1" style="background-color:rgb(180,180,180); width: 20%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 40%; color:#000000 ;">
        <col span="1" style="background-color:rgb(180,180,180); width: 40%; color:#000000 ;">
        
      </colgroup>
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      <col span="2"style="background-color:rgb(0,0,0); color:#FFFFFF">
      
      <tr>
        <th colspan="1"><div class="heading"></div></th>
        <th colspan="1"><div class="heading">slot 1</div></th>
        <th colspan="1"><div class="heading">slot 2</div></th>
      </tr>
      <tr>
        <td><div class="tabledata"> bits </div></td>
        <td><div class="tabledata" id = "b0"></div></td>
        <td><div class="tabledata" id = "b1"></div></td>
      </tr>
      <tr>
        <td><div class="tabledata"> volts </div></td>
        <td><div class="tabledata" id = "v0"></div></td>
        <td><div class="tabledata" id = "v1"></div></td>
      </tr>
     
  </table>

<div class="bodytext">  <br> </div>
 <br>
 
  <footer div class="foot" id = "temp" >  check out more maker projects on YouTube: <a href='https://www.youtube.com/@electronics.unmessed '> electronics unmessed </a> </div></footer>
  
  </body>


<script type = "text/javascript">
  
    // global variable visible to all java functions
    var xmlHttp=createXmlHttpObject();

    // function to create XML object
    function createXmlHttpObject(){
      if(window.XMLHttpRequest){
        xmlHttp=new XMLHttpRequest();
      }
      else{
        xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");
      }
      return xmlHttp;
    }

    // function to handle button press from HTML code above
    // and send a processing string back to server
    // this processing string is use in the .on method
    function ButtonPress0() {
      var xhttp = new XMLHttpRequest(); 
      var message;
      // if you want to handle an immediate reply (like status from the ESP
      // handling of the button press use this code
      // since this button status from the ESP is in the main XML code
      // we don't need this
      // remember that if you want immediate processing feedbac you must send it
      // in the ESP handling function and here
      /*
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          message = this.responseText;
          // update some HTML data
        }
      }
      */
       
      xhttp.open("PUT", "BUTTON_0", false);
      xhttp.send();
    }


    // function to handle button press from HTML code above
    // and send a processing string back to server
    // this processing string is use in the .on method
    function ButtonPress1() {
      var xhttp = new XMLHttpRequest(); 
      /*
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          document.getElementById("button1").innerHTML = this.responseText;
        }
      }
      */
      xhttp.open("PUT", "BUTTON_1", false);
      xhttp.send(); 
    }
    
    // my Button _10 +++++
    function ButtonPress10() {
      var xhttp = new XMLHttpRequest(); 
      xhttp.open("PUT", "BUTTON_10", false);
      xhttp.send(); 
    }

    // my Button _50 +++++
    function ButtonPress50() {
      var xhttp = new XMLHttpRequest(); 
      xhttp.open("PUT", "BUTTON_50", false);
      xhttp.send(); 
    }

    // my Button _100 +++++
    function ButtonPress100() {
      var xhttp = new XMLHttpRequest(); 
      xhttp.open("PUT", "BUTTON_100", false);
      xhttp.send(); 
    }

    // my Button _200 +++++
    function ButtonPress200() {
      var xhttp = new XMLHttpRequest(); 
      xhttp.open("PUT", "BUTTON_200", false);
      xhttp.send(); 
    }

    // my Button _01 START +++++
    function ButtonPress01() {
      var xhttp = new XMLHttpRequest(); 
      xhttp.open("PUT", "BUTTON_01", false);
      xhttp.send(); 
    }


    // my Button _00 STOP ++++++
    function ButtonPress00() {
      var xhttp = new XMLHttpRequest(); 
      xhttp.open("PUT", "BUTTON_00", false);
      xhttp.send(); 
    }

    // my Button _r1 RESET +++++
    function ButtonPressr1() {
      var xhttp = new XMLHttpRequest(); 
      xhttp.open("PUT", "BUTTON_r1", false);
      xhttp.send(); 
    }

    

    function UpdateSlider(value) {
      var xhttp = new XMLHttpRequest();
      // this time i want immediate feedback to the fan speed
      // yea yea yea i realize i'm computing fan speed but the point
      // is how to give immediate feedback
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
          // update the web based on reply from  ESP
          document.getElementById("fanrpm").innerHTML=this.responseText;
        }
      }
      // this syntax is really weird the ? is a delimiter
      // first arg UPDATE_SLIDER is use in the .on method
      // server.on("/UPDATE_SLIDER", UpdateSlider);
      // then the second arg VALUE is use in the processing function
      // String t_state = server.arg("VALUE");
      // then + the controls value property
      xhttp.open("PUT", "UPDATE_SLIDER?VALUE="+value, true);
      xhttp.send();
    }

    // function to handle the response from the ESP
    function response(){
      var message;
      var barwidth;
      var currentsensor;
      var xmlResponse;
      var xmldoc;
      var dt = new Date();
      var color = "#e8e8e8";
     
      // get the xml stream
      xmlResponse=xmlHttp.responseXML;
  
      // get host date and time
      document.getElementById("time").innerHTML = dt.toLocaleTimeString();
      document.getElementById("date").innerHTML = dt.toLocaleDateString();


      // slot length
      xmldoc = xmlResponse.getElementsByTagName("SL"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("sl").innerHTML=message;

      // scale factor
      xmldoc = xmlResponse.getElementsByTagName("SF"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("sf").innerHTML=message;

      // wifi rssi
      xmldoc = xmlResponse.getElementsByTagName("WI");
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("wi").innerHTML=message;

      // SW version
      xmldoc = xmlResponse.getElementsByTagName("VE"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("ve").innerHTML=message;

      // SR Start-Stop-Reset 1
      xmldoc = xmlResponse.getElementsByTagName("S1"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("s1").innerHTML=message;

      // laps togo 1
      xmldoc = xmlResponse.getElementsByTagName("L1"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("l1").innerHTML=message;

      // laps togo 2
      xmldoc = xmlResponse.getElementsByTagName("L2"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("l2").innerHTML=message;

      // laps togo 3 DIFF
      xmldoc = xmlResponse.getElementsByTagName("L3"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("l3").innerHTML=message;

      // last lap 1
      xmldoc = xmlResponse.getElementsByTagName("T1"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("t1").innerHTML=message;

      // last lap 2
      xmldoc = xmlResponse.getElementsByTagName("T2"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("t2").innerHTML=message;

      // last lap 3 DIFF
      xmldoc = xmlResponse.getElementsByTagName("T3"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("t3").innerHTML=message;

      // indicator best lap 1
      xmldoc = xmlResponse.getElementsByTagName("U1"); 
      message = xmldoc[0].firstChild.nodeValue;
      // document.getElementById("u1").innerHTML=message;
      if (message < 1){
        document.getElementById("e1").style.color="red"; 
      }
      else {
        document.getElementById("e1").style.color="yellow";
      }

      // indicator best lap 2
      xmldoc = xmlResponse.getElementsByTagName("U2"); 
      message = xmldoc[0].firstChild.nodeValue;
      // document.getElementById("u2").innerHTML=message;
      if (message < 1){
        document.getElementById("e2").style.color="red"; 
      }
      else {
        document.getElementById("e2").style.color="yellow";
      }

      // best lap 1
      xmldoc = xmlResponse.getElementsByTagName("E1"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("e1").innerHTML=message;

      // best lap 2
      xmldoc = xmlResponse.getElementsByTagName("E2"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("e2").innerHTML=message;

      // best lap 3 DIFF
      xmldoc = xmlResponse.getElementsByTagName("E3"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("e3").innerHTML=message;

      

      // av lap 1
      xmldoc = xmlResponse.getElementsByTagName("A1"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("a1").innerHTML=message;

      // av lap 2
      xmldoc = xmlResponse.getElementsByTagName("A2"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("a2").innerHTML=message;

      // av lap diff
      xmldoc = xmlResponse.getElementsByTagName("A3"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("a3").innerHTML=message;


      // Penalty time 1
      xmldoc = xmlResponse.getElementsByTagName("N1"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("n1").innerHTML=message;

      // Penalty time 2
      xmldoc = xmlResponse.getElementsByTagName("N2"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("n2").innerHTML=message;



      // tot time 1
      xmldoc = xmlResponse.getElementsByTagName("O1"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("o1").innerHTML=message;

      // tot time 2
      xmldoc = xmlResponse.getElementsByTagName("O2"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("o2").innerHTML=message;

      // tot time 3 diff
      xmldoc = xmlResponse.getElementsByTagName("O3"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("o3").innerHTML=message;

      // av speed 1
      xmldoc = xmlResponse.getElementsByTagName("P1"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("p1").innerHTML=message;

      // av speed 2
      xmldoc = xmlResponse.getElementsByTagName("P2"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("p2").innerHTML=message;

      // av speed 3 diff
      xmldoc = xmlResponse.getElementsByTagName("P3"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("p3").innerHTML=message;

      // race laps
      xmldoc = xmlResponse.getElementsByTagName("L0"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("l0").innerHTML=message;






      xmldoc = xmlResponse.getElementsByTagName("S1");
      message = xmldoc[0].firstChild.nodeValue;
      // update the text in the table
      if (message < 1){
        document.getElementById("s1").innerHTML="&bull;&bull;&bull;&bull;";
        document.getElementById("s1").style.color="red"; 
      }
      else {
        document.getElementById("s1").innerHTML="&bull;&bull;&bull;&bull;";
        document.getElementById("s1").style.color="#22FB03";
      }

      // SR Start-Stop-Reset 2
      xmldoc = xmlResponse.getElementsByTagName("S2"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("s2").innerHTML=message;

      xmldoc = xmlResponse.getElementsByTagName("S2");
      message = xmldoc[0].firstChild.nodeValue;
      // update the text in the table
      if (message < 1){
        document.getElementById("s2").innerHTML="&bull;&bull;&bull;&bull;";
        document.getElementById("s2").style.color="red"; 
      }
      else {
        document.getElementById("s2").innerHTML="&bull;&bull;&bull;&bull;";
        document.getElementById("s2").style.color="#22FB03";
      }

      // W1 Winner 1
      xmldoc = xmlResponse.getElementsByTagName("W1"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("w1").innerHTML=message;

      xmldoc = xmlResponse.getElementsByTagName("W1");
      message = xmldoc[0].firstChild.nodeValue;
      // update the text in the table
      if (message == 1){
        document.getElementById("w1").innerHTML="&#127942;"; 
      }
      else {
        document.getElementById("w1").innerHTML="";
      }

      // W1 Winner 2
      xmldoc = xmlResponse.getElementsByTagName("W2"); 
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("w2").innerHTML=message;

      xmldoc = xmlResponse.getElementsByTagName("W2");
      message = xmldoc[0].firstChild.nodeValue;
      // update the text in the table
      if (message == 1){
        document.getElementById("w2").innerHTML="&#127942;"; 
      }
      else {
        document.getElementById("w2").innerHTML="";
      }








      // A0
      xmldoc = xmlResponse.getElementsByTagName("B0"); //bits for A0
      message = xmldoc[0].firstChild.nodeValue;
      if (message > 2048){
      color = "#aa0000";
      }
      else {
        color = "#0000aa";
      }
      document.getElementById("b0").innerHTML=message;
      width = message / 40.95;
      document.getElementById("b0").style.width=(width+"%");
      document.getElementById("b0").style.backgroundColor=color;

      xmldoc = xmlResponse.getElementsByTagName("V0"); //volts for A0
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("v0").innerHTML=message;
      document.getElementById("v0").style.width=(width+"%");
      document.getElementById("v0").style.backgroundColor=color;


      // A1
      xmldoc = xmlResponse.getElementsByTagName("B1");
      message = xmldoc[0].firstChild.nodeValue;
      if (message > 2048){
      color = "#aa0000";
      }
      else {
      color = "#0000aa";
      }
      document.getElementById("b1").innerHTML=message;
      width = message / 40.95;
      document.getElementById("b1").style.width=(width+"%");
      document.getElementById("b1").style.backgroundColor=color;
      
      xmldoc = xmlResponse.getElementsByTagName("V1");
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("v1").innerHTML=message;
      document.getElementById("v1").style.width=(width+"%");
      document.getElementById("v1").style.backgroundColor=color;
  


      xmldoc = xmlResponse.getElementsByTagName("LED");
      message = xmldoc[0].firstChild.nodeValue;
  
      if (message == 0){
        document.getElementById("btn0").innerHTML="Turn ON";
      }
      else{
        document.getElementById("btn0").innerHTML="Turn OFF";
      }
         
      xmldoc = xmlResponse.getElementsByTagName("SWITCH");
      message = xmldoc[0].firstChild.nodeValue;
      document.getElementById("switch").style.backgroundColor="rgb(200,200,200)";
      // update the text in the table
      if (message == 0){
        document.getElementById("switch").innerHTML="Switch is OFF";
        document.getElementById("btn1").innerHTML="Turn ON";
        document.getElementById("switch").style.color="#0000AA"; 
      }
      else {
        document.getElementById("switch").innerHTML="Switch is ON";
        document.getElementById("btn1").innerHTML="Turn OFF";
        document.getElementById("switch").style.color="#00AA00";
      }
    }
  
    // general processing code for the web page to ask for an XML steam
    // this is actually why you need to keep sending data to the page to 
    // force this call with stuff like this
    // server.on("/xml", SendXML);
    // otherwise the page will not request XML from the ESP, and updates will not happen
    function process(){
     
     if(xmlHttp.readyState==0 || xmlHttp.readyState==4) {
        xmlHttp.open("PUT","xml",true);
        xmlHttp.onreadystatechange=response;
        xmlHttp.send(null);
      }       
        // you may have to play with this value, big pages need more porcessing time, and hence
        // a longer timeout
        setTimeout("process()",100);
    }
  
  
  </script>

</html>



)=====";
